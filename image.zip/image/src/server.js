
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs'); // Import the fs module
const app = express();

// Middleware to parse JSON data
app.use(express.json());

// Function to generate a random string
function generateRandomCode(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

// Setup storage with Multer
const storage = multer.diskStorage({
    destination: './public/',
    filename: function (req, file, cb) {
        const randomCode = generateRandomCode(10); // 10 random characters
        cb(null, randomCode + path.extname(file.originalname)); // Random filename with original extension
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 }, // 1MB limit
}).single('image');

// Middleware to serve static files
app.use(express.static('public'));

// Endpoint to upload image
app.post('/upload', (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            return res.status(500).json({ message: 'Gagal mengunggah gambar!' });
        }

        // Generate URL without the file extension
        const fileNameWithoutExt = req.file.filename.split('.')[0];
        const fileUrl = `${req.protocol}://${req.get('host')}/${fileNameWithoutExt}`;

        // Send image URL to the frontend
        res.status(200).json({ url: fileUrl });
    });
});

// Route to access the uploaded image
app.get('/:code', (req, res) => {
    const filePath = path.join(__dirname, '../public/');
    const code = req.params.code;

    fs.readdir(filePath, (err, files) => {
        if (err) {
            return res.status(500).send('Server error!');
        }

        const matchingFile = files.find(file => file.startsWith(code));
        
        if (matchingFile) {
            res.sendFile(path.join(filePath, matchingFile), (err) => {
                if (err) {
                    res.status(404).send('Gambar tidak ditemukan!');
                }
            });
        } else {
            res.status(404).send('Gambar tidak ditemukan!');
        }
    });
});

// Endpoint for the notepad generator
app.post('/notepad', (req, res) => {
    const { content, customUrl } = req.body;
    const randomCode = customUrl || generateRandomCode(10); // Use custom URL if provided
    const notepadPath = path.join(__dirname, '../public/', `${randomCode}.txt`); // Save as .txt file

    fs.writeFile(notepadPath, content, (err) => {
        if (err) {
            return res.status(500).json({ message: 'Gagal membuat notepad!' });
        }
        const notepadUrl = `${req.protocol}://${req.get('host')}/${randomCode}`;
        res.status(200).json({ url: notepadUrl });
    });
});

// Route to access the notepad
app.get('/:code.txt', (req, res) => {
    const notepadPath = path.join(__dirname, '../public/', `${req.params.code}.txt`);
    res.sendFile(notepadPath, (err) => {
        if (err) {
            res.status(404).send('Notepad tidak ditemukan!');
        }
    });
});

// Default route to show the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server berjalan pada port ${PORT}`));