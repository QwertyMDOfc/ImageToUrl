
// Event listener for navigation buttons
document.querySelectorAll('.feature-button').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();
        
        // Hide all feature sections
        document.querySelectorAll('.feature-section').forEach(section => {
            section.classList.add('hidden');
        });
        
        // Show the selected feature section
        const targetId = button.getAttribute('href');
        document.querySelector(targetId).classList.remove('hidden');
    });
});

// Image upload form handling
document.getElementById('uploadForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.url) {
            document.getElementById('result').innerHTML = `<p>Image URL: <a href="${data.url}" target="_blank">${data.url}</a></p>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('result').innerHTML = '<p>Error uploading image.</p>';
    });
});

// Notepad form handling
document.getElementById('notepadForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const content = this.content.value;
    const customUrl = this.customUrl.value;

    fetch('/notepad', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ content, customUrl })
    })
    .then(response => response.json())
    .then(data => {
        if (data.url) {
            document.getElementById('notepadResult').innerHTML = `<p>Notepad URL: <a href="${data.url}" target="_blank">${data.url}</a></p>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('notepadResult').innerHTML = '<p>Error generating notepad.</p>';
    });
});